<?php 
 $server = "localhost";
 $user = "root";
 $pass = "";
 $database = "modul3";

 $koneksi = mysqli_connect($server, $user, $pass, $database);
?>